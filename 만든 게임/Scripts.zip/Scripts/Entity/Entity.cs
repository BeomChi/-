using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity : MonoBehaviour,IDangeable
{
    // Start is called before the first frame update

    [Header("Entity ���� ����")]
    [SerializeField] private float  _hp;
    [SerializeField] private float  _maxHp;
    [SerializeField] private float  _attackPower;
    [SerializeField] private float  _maxStamina;             
    [SerializeField] private float  _stamina;
    [SerializeField] private float  _RecoverAmountPerSecondStamina;       // �ʴ� ���¹̳� ȸ����
    [SerializeField] private float  _moveSpeed;
    [SerializeField] private bool   _dead;
    [SerializeField] private bool   _invincibility;
    [SerializeField] private int    _gold;
    private bool _isAttack = false;

    private Material[] materials;        // ������Ʈ�� ���� Material
   


    public enum _state
    {
        idle = 0,
        isAttack,
        isMove,
        isDead,
    }
    public float RecoverAmountPerSecondStamina
    {
        get { return _RecoverAmountPerSecondStamina; }
        set { _RecoverAmountPerSecondStamina = value; }
    }
    public bool isAttack
    {
        get { return _isAttack; }
        set { _isAttack = value; }
    }
    public float maxStamina
    {
        get { return _maxStamina; }
        set { _maxStamina = value; }
    }
    public float maxHp
    {
        get { return _maxHp; }
        set { _maxHp = value; }
    }
    public float stamina
    {
        get { return _stamina; }
        set { _stamina = value; }
    }
    public float hp
    {
        get { return _hp; }
        set { _hp = value; }
    }

    public bool dead
    {
        get { return _dead; }
        set { _dead = value; }
    }

    public bool invincibility
    {
        get { return _invincibility; }
        set { _invincibility = value; }
    }

    public float moveSpeed
    {
        get { return _moveSpeed; }
        set { _moveSpeed = value; }
    }

    public float attackPower
    {
        get { return _attackPower; }
        set { _attackPower = value; }
    }

    public int gold
    {
        get { return _gold; }
        set { _gold = value; }
    }

    void Awake()
    {
        // ������Ʈ�� ���� Material ��������
        materials = GetComponentInChildren<Renderer>().materials;
        
    }
    private void OnDisable()
    {
        StopAllCoroutines(); // �ڷ�ƾ ����
    }

    private void OnEnable()
    {
        hp = maxHp;
        stamina = maxStamina;
        dead = false;

        materials = GetComponentInChildren<Renderer>().materials;


        foreach (Material mat in materials)
        {
            mat.SetFloat("_HitFlashIntensity", 0.0f);  // �÷��� ��Ȱ��ȭ
        }

    }

    // Update is called once per frame
    void Update()
    {
        StaminaRecovery();
    }

    public virtual void TakeDamage(float damage, Vector3 hitPoint, Vector3 hitNormal)    // ������ �Լ�
    {
        if (dead || invincibility)
            return;

        hp -= damage;

        StartCoroutine(FlashRed());

        if (hp < 0)
        {
            hp = 0;
            dead = true;
        }
    }

    public float GetHealth()
    {
        return hp;
    }

    public float DamageReduction(float damage,float decline_rate)   // ������ ������ ����� ������ ���
    {
        if (decline_rate < 0f || decline_rate > 1f)
        {
            Debug.Log("������ ���� ���� ����");
            return 0f;
        }
        return damage * (1 - decline_rate);
    }

    IEnumerator FlashRed()
    {
        // ��� ���׸��� ���� ������ �÷��� ȿ���� ����
        foreach (Material mat in materials)
        {
            mat.SetFloat("_HitFlashIntensity", 1.0f);  // ������ �÷��� Ȱ��ȭ
        }

        yield return new WaitForSeconds(0.3f);  // ��� ���

        // �ٽ� ���� ���·� ����
        foreach (Material mat in materials)
        {
            mat.SetFloat("_HitFlashIntensity", 0.0f);  // �÷��� ��Ȱ��ȭ
        }
    }

    protected void StaminaRecovery()
    {
        // ���� ���̸� ȸ���ȵǰ�
        if (isAttack)
            return;

        // ���¹̳� �ڵ� ȸ�� (�ʴ� 10�� ȸ��)
        stamina = Mathf.Min(maxStamina, stamina + RecoverAmountPerSecondStamina * Time.deltaTime);
    }
}
