using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimation : MonoBehaviour
{
    [SerializeField] private Transform PlayerBody; // �÷��̾��� ��ü�� ����
    [SerializeField] private ComboAnimation[] comboAnimations;
    private Animator anim;

    public int maxComboCount => comboAnimations.Length;

    [System.Serializable]
    public struct ComboAnimation
    {
        public string animationName;
        public float damageMultiplier;
    }

    public Animator Anim
    {
        get { return anim; }
    }

       

    void Start()
    {
        if (PlayerBody == null)
        {
            Debug.LogError("PlayerBody�� �������� �ʾҽ��ϴ�.");
            return;
        }

        anim = PlayerBody.GetComponent<Animator>();
        if (anim == null)
        {
            Debug.LogError("PlayerBody�� Animator ������Ʈ�� �����ϴ�.");
            return;
        }
    }


    // �÷��̿��� �����̴� ��
    public void isMovePlayer(bool isMove)
    {
        if (anim != null)
        {
            anim.SetBool("isMove", isMove);
        }
    }

    // ������ �ִϸ��̼�
    public void SetMovement(Vector2 moveInput)
    {
        if (anim != null)
        {
            anim.SetFloat("Horizontal", moveInput.x, 0.1f, Time.deltaTime);
            anim.SetFloat("Vertical",  moveInput.y, 0.1f, Time.deltaTime);

        }
    }

    public void SetRunMode(float speed)
    {
        if (anim != null)
            anim.SetFloat("isSpeed", speed);
    }
    public void SetDodge(Vector2 moveInput)
    {
        if (anim != null)
        {
            anim.SetFloat("Horizontal", moveInput.x);
            anim.SetFloat("Vertical", moveInput.y);

        }
    }

    // ���� �ִϸ��̼�
    public void SetGuardMotion(bool isBlock)
    {
        if (anim != null)
        {
            anim.SetBool("isBlock", isBlock);
        }
    }

    public void JumpAnim(bool isBool)
    {
        if (anim != null)
        {
            Debug.Log("�����ٖ���");
            anim.SetBool("isJump", isBool);
        }
    }

    public void PlayerJumpAnim()
    {
        StartCoroutine(JumpAnimation());
    }


    IEnumerator JumpAnimation()
    {
        JumpAnim(true);

        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.5f);
        JumpAnim(false);
    }

    // �޺� �ִϸ��̼� ����
    public void PlayComboAnimation(int comboIndex)
    {
        if (comboIndex >= 0 && comboIndex < comboAnimations.Length)
        {
            anim.SetTrigger("isAttack");
            anim.SetInteger("ComboCount",comboIndex);
        }
    }

    // ���� �ִϸ��̼� ����
    public float GetComboAnimationLength(int comboIndex)
    {
        if (comboIndex >= 0 && comboIndex < comboAnimations.Length)
        {
           
            //Debug.Log("����1�� �´���?" + anim.GetCurrentAnimatorStateInfo(0).IsName("Attack01"));
            //Debug.Log("���� �̸� " + comboAnimations[comboIndex].animationName);


            //Debug.Log("���� : " + anim.GetCurrentAnimatorStateInfo(0).length);
            //Debug.Log(anim.ToString());
            return anim.GetCurrentAnimatorStateInfo(0).length;
        }
        return 0f;
    }

    public void TriggerRollAnimation()
    {
        anim.SetTrigger("isRoll");
    }
}