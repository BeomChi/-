using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponBase : MonoBehaviour
{
    [SerializeField] protected Collider weaponCollider;
    [SerializeField] protected float damage = 10;

    [SerializeField] private WeaponType weaponType;

    [SerializeField] private bool _isAttackCheck;

    public AudioClip swingSound;  // ���� �ֵθ��� �Ҹ�
    public AudioClip hitSound;    // Ÿ�� �Ҹ�
    AudioSource audioSource;

    public enum WeaponType
    {
        melee = 0,
        projectil,
    }

    public bool IsAttackCheck
    {
        get { return _isAttackCheck; }
        set { _isAttackCheck = value; }
    }
    //private PlayerInfo playerInfo;
    // Start is called before the first frame update
    protected virtual void Start()
    {

        if (weaponCollider != null && weaponType == WeaponType.melee)
        {
            Debug.Log(this.name+"�ݶ��̴� �ʱ�ȭ");
            weaponCollider.enabled = false;
        }

        audioSource = GetComponent<AudioSource>();
    }

    public virtual void EnableWeaponCollider()
    {
        if (weaponCollider != null)
        {
            weaponCollider.enabled = true;
        }
    }

    public virtual void DisableWeaponCollider()
    {
        if (weaponCollider != null)
        {
            weaponCollider.enabled = false;
        }
    }
    public void SetDamage(float Damage)
    {
        damage = Damage;

    }
    // ���� �ֵθ��� �Ҹ� ���
    public void PlaySwingSound()
    {
        audioSource.PlayOneShot(swingSound);  // �ֵθ��� �Ҹ�
    }

    // �´� ���� �ǰ� �Ҹ� ���
    public void PlayHitSound()
    {
        audioSource.PlayOneShot(hitSound);  // Ÿ�� �Ҹ�
    }


    protected virtual void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("PubuSpawn") && this.CompareTag("PlayerWeapon"))
        {
            other.gameObject.SetActive(false);
            return;
        }

        if (this.tag != other.tag)
        {
            if (!_isAttackCheck && other.gameObject.GetComponent<Entity>() != null)
            {
                Vector3 hitPoint = other.ClosestPoint(transform.position);
                Vector3 hitNormal = transform.position - other.transform.position;


                other.gameObject.GetComponent<Entity>().TakeDamage(damage, hitPoint, hitNormal);
                Debug.Log(other.name + "ü�� : " + other.gameObject.GetComponent<Entity>().GetHealth());
                _isAttackCheck = true;
                DisableWeaponCollider();
                PlayHitSound();
            }
        }

    }

    
}
