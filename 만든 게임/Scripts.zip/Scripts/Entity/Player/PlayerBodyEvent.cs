using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBodyEvent : MonoBehaviour
{
    public AudioSource audioSource;  // ���带 ����� AudioSource
    public AudioClip swingSound;     // �ֵθ��� �Ҹ�
    private PlayerManager playerManager;
    
    public Camera camera;
    public float duration = 0.5f; // ����ũ ���� �ð�
    public float magnitude = 0.1f; // ����ũ ����
    private void Start()
    {
        // �ֻ��� �θ� �ִ� PlayerController ��ũ��Ʈ�� ã��
        //playerManager = GetComponentInParent<PlayerManager>();
        playerManager = PlayerManager.Instance;
    }

    public void ResetAttack()
    {
        if (playerManager != null)
        {
            playerManager.PlayerAttack.ResetAttack();
        }
    }

    public void StartParryWindow()
    {
        if (playerManager != null)
        {
            playerManager.PlayerAssasinAttack.StartParryWindow();
        }
    }

    public void EndParryWindow()
    {
        if (playerManager != null)
        {
            playerManager.PlayerAssasinAttack.EndParryWindow();
        }
    }

    public void SetFalseisAttack()
    {
        if(playerManager != null)
        {
            playerManager.PlayerInfo.isAttack = false;
        }
    }

    public void PlaySwingSound()
    {
        audioSource.PlayOneShot(swingSound);
    }

    public void StartShake()
    {
        StartCoroutine(Shake());
    }


    public IEnumerator Shake()
    {
        Vector3 originalPosition = camera.transform.localPosition;
        float elapsed = 0.0f;

        while (elapsed < duration)
        {
            float x = Random.Range(-1f, 1f) * magnitude;
            float y = Random.Range(-1f, 1f) * magnitude;

            camera.transform.localPosition = new Vector3(originalPosition.x + x, originalPosition.y + y, originalPosition.z);

            elapsed += Time.deltaTime;

            yield return null;
        }

        camera.transform.localPosition = originalPosition; // ���� ��ġ�� ����
    }
}
