using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IDangeable
{
    void TakeDamage(float damage, Vector3 hitPoint, Vector3 hitNormal);
    float GetHealth();
}
