using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class MonsterMovement : MonoBehaviour
{
    private NavMeshAgent _navMeshAgent;

    [SerializeField] private Transform _target;         // �÷��̾�
    [SerializeField] private Transform[] _waitPoint;    // ������ų ��������Ʈ
    [SerializeField] private float _chaseDistance;      // ���� �÷��̾� �ν� �Ÿ�
    [SerializeField] private float _attackRange;        // ���� �Ÿ�
    [SerializeField] private float _wanderRadius;       // ���� �Ÿ�

    private MonsterBaseInfo _monsterBaseInfo;           // ������ �⺻ ������ ��� �ִ� ��ũ��Ʈ
    private bool _isChasing = false;                    // ���Ͱ� �÷��̾ �Ѱ� �ִ��� ����
    private int _currentWaitPintIndex;
    private Rigidbody _rigidbody;

    public Transform target { get { return _target; } }
    public NavMeshAgent navMeshAgent { get { return _navMeshAgent; } }
    public float attackRange 
    { 
        get { return _attackRange; } 
        set { _attackRange = value; }
    }

    public float distanceToTarget;
    protected Animator _anim;
    private void Awake()
    {
        _anim = GetComponent<Animator>();
        _rigidbody = GetComponent<Rigidbody>();
        _navMeshAgent = GetComponent<NavMeshAgent>();
        _monsterBaseInfo = GetComponent<MonsterBaseInfo>(); // MonsterBase ��ũ��Ʈ ����
        
        
    }
    // Start is called before the first frame update
    void Start()
    {
        _navMeshAgent.speed = _monsterBaseInfo.moveSpeed;   // �⺻ �̵��ӵ� ����

        if (_waitPoint.Length > 0)
        {
            _navMeshAgent.SetDestination(_waitPoint[_currentWaitPintIndex].position);
        }
        _navMeshAgent = GetComponent<NavMeshAgent>();
    }


    // ��Ȱ��ȭ�� �� ȣ��
    private void OnDisable()
    {

        // ���� ���¸� ��� �ʱ�ȭ�ϰų� �ߴ�
        _target = null;
        _navMeshAgent.enabled = false;

       
        StopAllCoroutines(); // �ڷ�ƾ ����
    }

    private void OnEnable()
    {

        // NavMeshAgent �缳��
        if (_navMeshAgent == null)
            Debug.Log("���� ����");

        _monsterBaseInfo.isAttack = false;

        navMeshAgent.enabled = false;
        _navMeshAgent.enabled = true;
        _navMeshAgent.isStopped = false;
        _navMeshAgent.ResetPath();  // ��� �ʱ�ȭ
        navMeshAgent.Warp(transform.position);  // ���� ��ġ���� ��� �缳��

        Debug.Log("NavMeshAgent Path Status: " + navMeshAgent.pathStatus);
        //MonsterState();

        navMeshAgent.updateRotation = true;

        distanceToTarget = _chaseDistance;

        _monsterBaseInfo.ChangeState(MonsterBaseInfo.MonsterState.idle);


        if (_anim == null)
        {
            Debug.LogError("Animator not found on monster!");
        }

        if (_anim != null)
        {
            _anim.Rebind();
            _anim.Update(0);
        }

        transform.rotation = Quaternion.Euler(0, 180, 0);
    }

    private void FixedUpdate()
    {
        FreezeVector();
    }


    // Update is called once per frame
    void Update()
    {
        MonsterState();
        MonsterMoveAnim();
    }


    void MonsterMoveAnim()
    {
        // ������ �̵� ������ ���� ��ǥ��� ��ȯ�Ͽ� ���
        Vector3 movement = transform.InverseTransformDirection(navMeshAgent.velocity);

        // X(�¿�)�� Y(�յ�) �̵� ���� �ִϸ����Ϳ� ����
        _anim.SetFloat("Horizontal", movement.x);
        _anim.SetFloat("Vertical", movement.z);

        //  �ȱ�/�޸��� �ִϸ��̼� ��ȯ�� ���� �ӵ� ����
        //_anim.SetFloat("Speed", navMeshAgent.velocity.magnitude);

        // ���Ͱ� �̵����� ���� �� (���� ����)
        if (navMeshAgent.velocity.sqrMagnitude < 0.1f)
        {
            _anim.SetBool("isMove", false);
        }
        else
        {
            _anim.SetBool("isMove", true);
        }

        
    }

    void FreezeVector()
    {
        _rigidbody.velocity = Vector3.zero;
        _rigidbody.angularVelocity = Vector3.zero;
    }
    void MonsterState()
    {
        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.standoff)
            return;

        if (_monsterBaseInfo.isAttack)
            return;

        if (_target == null)
        {
            Wonder();
            return;
        }

        // �÷��̾������ �Ÿ�
        float distanceToTarget = Vector3.Distance(transform.position, _target.position);
        if (distanceToTarget <= _attackRange)
        {
            AttackToRange();
        }
        else //if(distanceToTarget <=_chaseDistance)
        {
            ChaseTarget();
        }
        
    }

    // ��Ȳ
    void Wonder()
    {
        if(_navMeshAgent.remainingDistance < 0.2f)
        {
            Vector3 newTargetPosition = GetRandomWanderPosition();
            _navMeshAgent.SetDestination(newTargetPosition); 
            _monsterBaseInfo.ChangeState(MonsterBaseInfo.MonsterState.move);
        }

        Collider[] hitClolliders = Physics.OverlapSphere(transform.position, _chaseDistance);

        foreach(var collider in  hitClolliders)
        {
            if(collider.CompareTag("Player"))
            {
                _target = collider.transform;
                _monsterBaseInfo.ChangeState(MonsterBaseInfo.MonsterState.tracking);
                break;
            }
        }
    }

    // ��Ȳ�� �� ���ο� ��ǥ ��ġ�� ��ȯ�ϴ� �Լ�
    Vector3 GetRandomWanderPosition()
    {
        Vector3 randomDirection = Random.insideUnitSphere * _wanderRadius;

        randomDirection += transform.position;

        NavMeshHit navHit;

        NavMesh.SamplePosition(randomDirection, out navHit, _wanderRadius, NavMesh.AllAreas);
        return navHit.position;
    }

    // ����
    void ChaseTarget()
    {
        if (_target != null)
        {
            if (_monsterBaseInfo.isAttack)
                return;

            _navMeshAgent.isStopped = false;
            _isChasing = true;
            _navMeshAgent.SetDestination(_target.position);
            _monsterBaseInfo.ChangeState(MonsterBaseInfo.MonsterState.tracking);

            distanceToTarget = Vector3.Distance(transform.position, _target.position);
            if(distanceToTarget > _chaseDistance)
            {
                _target = null;
                _monsterBaseInfo.ChangeState(MonsterBaseInfo.MonsterState.move);
            }
        }
    }

    // ����
    void AttackToRange()
    {
        // �÷��̾� ��ġ ����ؼ� �ʱ�ȭ
        distanceToTarget = Vector3.Distance(transform.position, _target.position);
        //Debug.Log("���ܸ�� ��ȯ");]


        // �̵� ����
        _navMeshAgent.isStopped = true;

        // ���ݻ��� Ȱ��ȭ
        _monsterBaseInfo.ChangeState(MonsterBaseInfo.MonsterState.attack);
    
    }

    // ��ǥ ����
    public void SetTarget(Transform target)
    {
        _target = target;
        _isChasing = true;
    }

    
    private void OnDrawGizmosSelected()
    {
        // ���� Ȯ�� ��

        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, _chaseDistance);

        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, _attackRange);
    }

    
}
