using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TvBoss : MonsterAttack
{
    [Header("1������ ���")]
    public GameObject _page1Boom;
    public GameObject _page1Wave;

    private void Start()
    {
        StartCoroutine(TvPatton());
    }    
    private IEnumerator TvPatton()
    {
        while(true)
        {
            yield return null;
            int ranPattonCount = Random.Range(2, 5);
            for (int i = 0; i < ranPattonCount; i++)
            {
                yield return null;

                if(!anim.GetBool("Page2"))
                    yield return new WaitUntil(() => _monsterMovement.distanceToTarget < 10.0f);
                else
                    yield return new WaitUntil(() => _monsterMovement.distanceToTarget < 5.0f);

                              
                _monsterMovement.navMeshAgent.isStopped = true;

                int ranPattoon = Random.Range(1, 3);
                anim.SetInteger("Patton", ranPattoon);
                
                if (!anim.GetBool("Page2"))
                    attackJudgment[ranPattoon - 1].IsAttackCheck = false;
                else
                    attackJudgment[ranPattoon + 1].IsAttackCheck = false;

                yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f);
                if (anim.GetBool("Page2") && ranPattoon == 2)
                {
                    _monsterMovement.navMeshAgent.isStopped = false;
                    _monsterBaseInfo.moveSpeed = 5f;
                    yield return new WaitForSeconds(3);
                }                
                anim.SetInteger("Patton", 0);
                _monsterMovement.navMeshAgent.isStopped = false;
                

                yield return new WaitForSeconds(3);
            }
            anim.SetBool("Page2", !anim.GetBool("Page2"));

            yield return new WaitForSeconds(2);

            if (anim.GetBool("Page2"))
                _monsterBaseInfo.moveSpeed = 4f;
            else
                _monsterBaseInfo.moveSpeed = 2f;            
        }
    }
    public void Page1Wave()
    {
        attackJudgment[0].IsAttackCheck = false;
        _page1Wave.SetActive(true);
        StartCoroutine(AnimCheck(_page1Wave));
    }

    public void Page1Boom()
    {
        attackJudgment[0].IsAttackCheck = false;
        _page1Boom.SetActive(!_page1Boom.activeSelf);
        Vector3 playerPostion = _monsterMovement.target.position;
        playerPostion.y = 0;
        _page1Boom.transform.position = playerPostion;
        StartCoroutine(AnimCheck(_page1Boom));
    }
    private IEnumerator AnimCheck(GameObject obj)
    {
        yield return new WaitUntil(() => obj.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime >= 1.0f);
        obj.SetActive(false);
    }
}
