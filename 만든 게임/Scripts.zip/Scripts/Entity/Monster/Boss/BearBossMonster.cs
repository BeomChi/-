using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BearBossMonster : MonsterAttack
{
    // TODO
    // ���� ã�� �ǰ���(��Ź�� �б⿡ �´� �Ҹ�)
    // �� �ֵθ��� �Ҹ�(�˵� �ֵ�)
    // �ĵ� �Ҹ�()


    [SerializeField] private float rangeRadius;     // ����
    [SerializeField] int numOfProjectiles;          // ����ü ����
    [SerializeField] float minDistanceBetwee;       // ����ü �� �ּ� �Ÿ�
    [SerializeField] Transform spawnAreaCenter;     // ���� ���� �߽�
    [SerializeField] private float delayBeforeAttack;
    [SerializeField] private List<Vector3> projectilePos = new List<Vector3>();  // ��ġ�� �ʴ� ����ü ��ġ ����
    [SerializeField] private List<GameObject> projectileList = new List<GameObject>();  // ����ü ����
    [SerializeField] private List<GameObject> spawnCount;
    
    private int Count = 0;
    int ComboAttackCount = 0;

    private void Start()
    {
        StartCoroutine(UiManagerInput());
    }
    private void Update()
    {
        MonsterStateLogic();        
    }
    private IEnumerator UiManagerInput()
    {
        while (true)
        {
            yield return null;
            if(_monsterMovement.target != null)
            {
                _monsterMovement.target.GetComponent<PlayerInfo>()._ui_Manager.BossHpBarOn("�Ұ�", _monsterBaseInfo.maxHp);
                break;
            }
        }
    }
    public void ComboAttack()
    {
        // �ٸ� ���� ������ ���� ������
        if (AttackCoroutine != null)
            return;

        AttackCoroutine = StartCoroutine(ComboAttackCoroutin());
    }

    
    IEnumerator ComboAttackCoroutin()
    {
        // ���� ���� Ȱ��ȭ
        _monsterBaseInfo.isAttack = true;

        while (ComboAttackCount < 3)
        {
            // �÷��̾� �������� ������ �ٶ󺸰� �ϰ�
            transform.LookAt(_monsterMovement.target);
            SetDamage(0, attackPattern[0].damage);

            // �ִϸ��̼� �ӵ� ����
            anim.SetFloat("AttackSpeed", 0.5f);

            // �ִϸ��̼� ȣ��
            anim.SetInteger("AttackComboCount", ComboAttackCount + 1);

            if (ComboAttackCount == 2)
            {
                anim.SetFloat("AttackSpeed", 0.25f);
                yield return new WaitForSeconds(1f);
            }

            anim.SetFloat("AttackSpeed", 1f);

            // ������ ����
            SetDamage(ComboAttackCount + 1, attackPattern[1].damage);

            // ���� Ȱ��ȭ
            attackJudgment[ComboAttackCount + 1].EnableWeaponCollider();

            // �ִϸ��̼� ������� ���
            yield return new WaitForSeconds(1f);

            attackJudgment[ComboAttackCount + 1].DisableWeaponCollider();
            ComboAttackCount++;
            attackJudgment[ComboAttackCount + 1].IsAttackCheck = false;
        }

        ComboAttackCount = 0;

        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
        
    }

    public void RandomRangeAttack()
    {
        // �ٸ� ���� ������ ���� ������
        if (AttackCoroutine != null)
            return;

        GenerateNonOverlappingPositions();
        AttackCoroutine = StartCoroutine(RandomRangeAttackCoroutine());
    }

    // ���� ��ġ ����
    void GenerateNonOverlappingPositions()
    {
        _monsterBaseInfo.isAttack = true;
        projectilePos.Clear();

        for (int i = 0; i < numOfProjectiles; i++)
        {
            Vector3 randomPos = new Vector3(0, 0, 0);
            bool posValid = false;

            while (!posValid)
            {
                // ���� �� ���� ��ġ ����
                float randX = Random.Range(-rangeRadius, rangeRadius);
                float randZ = Random.Range(-rangeRadius, rangeRadius);

                randomPos = new Vector3(randX, 5, randZ) + spawnAreaCenter.position;

                // �ٸ� ��ġ�� �Ÿ� Ȯ�� ��ġ�� �ʴ� �� Ȯ��
                posValid = true;
                foreach (Vector3 pos in projectilePos)
                {
                    if(Vector3.Distance(randomPos, pos) < minDistanceBetwee)
                    {
                        posValid = false;
                        break;
                    }
                }
            }
            projectilePos.Add(randomPos);

        }
    }

    IEnumerator RandomRangeAttackCoroutine()
    {
        // �ִϸ��̼� ����
        anim.SetTrigger("isRandAttack");

        // ��ġ�� �ʴ� ���� ����
        foreach (Vector3 position in projectilePos)
        {
            GameObject obj = ObjectPool.Instance.GetPooledObject("sparrow");
            Projectile projectileScript = obj.GetComponent<Projectile>();
            projectileScript.isStop = true;
            obj.transform.position = position;
            obj.transform.rotation = Quaternion.identity;

            obj.SetActive(true);

            projectileList.Add(obj);
        }

        // ������ ����
        SetDamage(0, attackPattern[0].damage);

        //
        foreach (GameObject obj in projectileList)
        {
            Projectile projectileScript = obj.GetComponent<Projectile>();
            
            projectileScript.SetTarget(_monsterMovement.target.transform.position);
            projectileScript.isStop = false;

            yield return new WaitForSeconds(0.5f);  // �� ����ü ���� ���� �ð� ����
        }

        _monsterBaseInfo.isAttack = false;
        projectileList.Clear();
        AttackCoroutine = null;
    }

    public void SmashAttack()
    {
        if (AttackCoroutine != null)
            return;

        AttackCoroutine = StartCoroutine(PerformSmahAttack());
    }

    IEnumerator PerformSmahAttack()
    {
        // ���ݻ���
        _monsterBaseInfo.isAttack = true;

        // �÷��̾ �ٶ󺸰�
        transform.LookAt(_monsterMovement.target);

        // ���ݹ��� ǥ��
        GameObject attackIndicator = ObjectPool.Instance.GetPooledObject("SmashIndicate");
        attackIndicator.transform.position = attackJudgment[3].transform.position;
        attackIndicator.SetActive(true);

        // ������ �ʱ�ȭ
        SetDamage(3, attackPattern[2].damage);

        // �ִϸ��̼� ����
        anim.SetTrigger("isSmash");
        anim.SetFloat("AttackSpeed", 0.5f);

        // �ִϸ��̼� ���ൿ�� ���
        yield return new WaitForSeconds(1f);
        anim.SetFloat("AttackSpeed", 1f);

        // ���� ���� ǥ�� ����
        attackIndicator.SetActive(false);

        // ���� ����
        attackJudgment[3].EnableWeaponCollider();
        yield return new WaitForSeconds(0.2f);
        attackJudgment[3].DisableWeaponCollider();

        // �ڷ�ƾ ����
        attackJudgment[3].IsAttackCheck = false;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }

    public void StartRangeChargeAttack()
    {
        if (AttackCoroutine != null)
            return;

        _monsterBaseInfo.isAttack = true;
        _monsterMovement.attackRange = 15;
        Vector3 targetPos = _monsterMovement.target.transform.position;
        RangeChargeAttack(targetPos);
    }

    public void RangeChargeAttack(Vector3 targetPos)
    {

        AttackCoroutine = StartCoroutine(RangedChargeAttackCoroutine(targetPos));
    }

    IEnumerator RangedChargeAttackCoroutine(Vector3 targetPos)
    {
        // ���� ���� ǥ��
        GameObject attackIndicator = ObjectPool.Instance.GetPooledObject("Indicate");
        attackIndicator.transform.position = targetPos;
        attackIndicator.transform.rotation = Quaternion.identity;

        attackIndicator.SetActive(true);

        yield return new WaitForSeconds(delayBeforeAttack);

        PerformRangedChargeAttack(targetPos);

        attackIndicator.SetActive(false);

        _monsterBaseInfo.isAttack = false;
        _monsterMovement.attackRange = 3;
        AttackCoroutine = null;
    }

    private void PerformRangedChargeAttack(Vector3 targetPos)
    {

        // ���� ���� ����
        GameObject projectile = ObjectPool.Instance.GetPooledObject("Pudu");

        if (projectile == null)
            return;

        Debug.Log("�߻� �غ�");

        anim.SetTrigger("RangeChargeAttack");

        // ����ü �߻� ��ġ ����
        Projectile projectileScript = projectile.GetComponent<Projectile>();

        if (projectileScript == null)
        {
            Debug.LogError("����ü ��ũ��Ʈ�� ����");
            return;
        }

        // �߻� ��ġ
        projectile.transform.position = attackJudgment[3].transform.position;
        

        projectileScript.SetTarget(targetPos);

        // ������ ����
        SetDamage(4, attackPattern[3].damage);

        // ����ü Ȱ��ȭ
        projectile.SetActive(true);

        spawnCount.Add(projectile);
        Count++;
    }

    void ReTargetingAttack()
    {
        anim.SetTrigger("isRetarget");

        foreach (GameObject obj in spawnCount)
        {
            if (obj != null)
            {
                obj.GetComponent<Projectile>().SetTarget(_monsterMovement.target.transform.position);
            }
        }

        Count = 0;
        //spawnCount.Clear();
    }

    void MonsterStateLogic()
    {
        // ���� ���̸�
        if (_monsterBaseInfo.isAttack)
            return;

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.standoff)
        {
            StartObservePlayer();
        }


        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack)
        {
            TryAttack(1);
        }

        if (_monsterMovement.distanceToTarget > _monsterMovement.attackRange * 2
            && _monsterMovement.distanceToTarget != 0)
        {
            TryAttack(0);
        }

        // 2 ������
        if (_monsterBaseInfo.hp < _monsterBaseInfo.maxHp * 0.6f)
        {
            
            if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack)
            {
                TryAttack(2);
            }

            if (_monsterMovement.distanceToTarget > _monsterMovement.attackRange * 1.5f)
            {
                TryAttack(3);
            }

            if (Count > 5)
            {
                ReTargetingAttack();
            }

        }
    }

    private void OnDrawGizmosSelected()
    {
        // ���� Ȯ�� ��
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, rangeRadius);
    }
}
