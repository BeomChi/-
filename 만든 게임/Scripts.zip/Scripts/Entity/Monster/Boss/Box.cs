using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Box : MonsterAttack
{

    public void Start()
    {
        //StartCoroutine(ShowMimic());
    }

    private void OnEnable()
    {
        StartCoroutine(ShowMimic());
    }
    private IEnumerator ShowMimic()
    {
        while (true)
        {
            yield return null;
            if (_monsterMovement.distanceToTarget < 1.0f && _monsterMovement.target != null)
            {
                anim.SetTrigger("Open");
                _monsterMovement.target.GetComponent<PlayerInfo>().gold += 200;
                _monsterMovement.target.GetComponent<PlayerInfo>()._ui_Manager.GoldGuide();
                break;
            }
        }

        yield return new WaitForSeconds(3f);

        _monsterBaseInfo.TakeDamage(10, transform.position, transform.position);
    }
}
