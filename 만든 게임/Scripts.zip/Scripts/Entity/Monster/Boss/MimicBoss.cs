using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class MimicBoss : MonsterAttack
{

    public void Start()
    {
        //StartCoroutine(ShowMimic());
    }

    private void OnEnable()
    {
        StartCoroutine(ShowMimic());
    }
    private IEnumerator ShowMimic()
    {
        while (true)
        {
            yield return null;
            if (_monsterMovement.distanceToTarget < 1.0f && _monsterMovement.target != null)
            {
                attackJudgment[0].IsAttackCheck = false;
                anim.SetTrigger("Show");
                StartCoroutine(MimicPatton());
                break;
            }
            else if(_monsterBaseInfo.maxHp != _monsterBaseInfo.hp)
            {
                anim.SetTrigger("Hit");
                StartCoroutine(MimicPatton());
                break;
            }
        }
    }
    private IEnumerator MimicPatton()
    {
        _monsterMovement.target.GetComponent<PlayerInfo>()._ui_Manager.BossHpBarOn("�̹�", _monsterBaseInfo.maxHp);
        while(true)
        {
            yield return null;

            int ranNum = Random.Range(1, 4);
            anim.SetInteger("Pattern", ranNum);

            attackJudgment[ranNum - 1].IsAttackCheck = false;

            attackJudgment[ranNum - 1].EnableWeaponCollider();
            yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f);                        

            anim.SetInteger("Pattern", 0);

            yield return new WaitForSeconds(Random.Range(2, 4));
        }
    }
}
