using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterBaseInfo : Entity
{
    
    [SerializeField] private MonsterState _currentState;                                          // �ʱ� �� ����                                       // ��� ����
    public ParticleSystem hitEffect;


    private float defaultMoveSpeed;                                     // �ʱ� �� ����
    private float defaultAttackPower;                                   // �ʱ� �� ����
    private Animator anim;
    private Ui_Manager uiManager;

    PlayerManager playerManager;

    public float duration = 0.5f; // ����ũ ���� �ð�
    public float magnitude = 0.1f; // ����ũ ����

    public MonsterState currentState
    {
        get { return _currentState; }
        set { _currentState = value; }
    }
    
    
    public enum MonsterType
    {
        Melee,
        Ranged,
    }

    public enum MonsterState
    {
        idle = 0,           // �⺻
        attack,             // ����
        move,               // �̵�
        standoff,           // ��ġ
        tracking,           // ����
    }

    void Start()
    {
        // Entity���� ��ӹ��� �ʱ� �� ����
        defaultMoveSpeed = moveSpeed;
        defaultAttackPower = attackPower;
        hp = maxHp;
        stamina = maxStamina;
        dead = false;

        //
        anim = GetComponent<Animator>();

        playerManager = PlayerManager.Instance;
        
    }

    


    public override void TakeDamage(float damage,Vector3 hitPoint,Vector3 hitNormal)
    {
        //hitEffect.transform.position = hitPoint;
        //hitEffect.transform.rotation = Quaternion.LookRotation(hitNormal);
        //hitEffect.Play();

        base.TakeDamage(damage, hitPoint, hitNormal);  // �θ� Ŭ������ ������ ó�� ���� ȣ��

        if(!isAttack)
            anim.SetTrigger("isHit");

        if (hp <= 0)   //&& !dead
        {
            Die();
            
        }
        if(uiManager == null)
            uiManager = this.GetComponent<MonsterMovement>().target.GetComponent<PlayerInfo>()._ui_Manager;

        uiManager.BossHpAccese(hp);
    }

    private void Die()
    {
        dead = true;
        Debug.Log("���� ���");

        playerManager.PlayerInfo.TakeGold(gold);
        playerManager.PlayerInfo.monsterCount++;

        StartCoroutine(DeadAnimationPlay());
    }

    IEnumerator DeadAnimationPlay()
    {
        // ��� �ִϸ��̼� ���
        anim.SetTrigger("isDead");

        yield return new WaitForSeconds(1);

        gameObject.SetActive(false);
    }


    // ���� ����
    public void ChangeState(MonsterState newState)
    {
        currentState = newState;
    }

}
