using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterBasicMelee : MonsterAttack
{
    public void Update()
    {
        BattleStatusLogic();
    }
    public void SwingAttack()
    {
        if (AttackCoroutine != null)
            return;

        Debug.Log("�⺻ ����");

        AttackCoroutine = StartCoroutine(SwingAttackCoroutin()); 
    }
    IEnumerator SwingAttackCoroutin()
    {
        // ���� ���� Ȱ��ȭ
        _monsterBaseInfo.isAttack = true;
        attackJudgment[0].IsAttackCheck = false;

        // �÷��̾� �������� ������ �ٶ󺸰� �ϰ�
        transform.LookAt(_monsterMovement.target);
        SetDamage(0, attackPattern[1].damage);

        // �ִϸ��̼� ȣ��
        anim.SetTrigger("isAttack");

        // �ִϸ��̼� �̺�Ʈ�� ���⿡ ���� ���� ���ٰ� ���� �� �ֱ�
        //attackJudgment[0].EnableWeaponCollider();

        // �ִϸ��̼��� ���������� ���
        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.95f);

        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }
    
    public void JumpAttack()
    {
        if (AttackCoroutine != null)
            return;
        Debug.Log("���� ����");

        AttackCoroutine = StartCoroutine(JumpAttackCoroutin());

    }

    IEnumerator JumpAttackCoroutin()
    {
        // ���� ���� Ȱ��ȭ
        _monsterBaseInfo.isAttack = true;
        _monsterMovement.navMeshAgent.isStopped = true;
        attackJudgment[0].IsAttackCheck = false;

        // �÷��̾� �������� ������ �ٶ󺸰� �ϰ�
        transform.LookAt(_monsterMovement.target);
        SetDamage(0,attackPattern[0].damage);

        // �ִϸ��̼� ȣ��
        anim.SetTrigger("isJumpAttack");

        //attackJudgment[0].EnableWeaponCollider();

        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.95f);
        
        // �ִϸ��̼� �̺�Ʈ�� ���⿡ ���� ���� ���ٰ� ���� �� �ֱ�
        attackJudgment[0].DisableWeaponCollider();

        _monsterMovement.navMeshAgent.isStopped = false;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
        yield return null;
    }

    public void OneHandeComboAttack()
    {
        if (AttackCoroutine != null)
            return;
        
        AttackCoroutine = StartCoroutine(OneHandeComboAttackCoroutin());
    }

    IEnumerator OneHandeComboAttackCoroutin()
    {
        // ���� ���� Ȱ��ȭ
        _monsterBaseInfo.isAttack = true;
        SetDamage(0,attackPattern[2].damage);

        transform.LookAt(_monsterMovement.target);
        anim.SetTrigger("OneHandeComboAttack");

        attackJudgment[0].EnableWeaponCollider();
        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f);
        attackJudgment[0].DisableWeaponCollider();

        attackJudgment[0].IsAttackCheck = false;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
        yield return null;
    }

    public void CactusAttack()
    {
        if (AttackCoroutine != null)
            return;

        AttackCoroutine = StartCoroutine(CactusAttackCoroutin());
    }

    IEnumerator CactusAttackCoroutin()
    {
        _monsterBaseInfo.isAttack = true;

        SetDamage(0, attackPattern[1].damage);

        anim.SetTrigger("isAttack");

        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.3f);
        attackJudgment[0].EnableWeaponCollider();
        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.5f);
        attackJudgment[0].DisableWeaponCollider();
        attackJudgment[0].IsAttackCheck = false;

        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.6f);

        attackJudgment[0].EnableWeaponCollider();
        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.8f);
        attackJudgment[0].DisableWeaponCollider();

        attackJudgment[0].IsAttackCheck = false;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }

    public virtual void BattleStatusLogic()
    {
        // ���� ���̸�
        if (_monsterBaseInfo.isAttack)
            return;

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.standoff)
        {
            StartObservePlayer();
        }


        if ((_monsterMovement.attackRange * 2) > _monsterMovement.distanceToTarget
            && _monsterBaseInfo.currentState != MonsterBaseInfo.MonsterState.attack
            && _monsterMovement.target != null)
        {
            TryAttack(0);
        }

        if(_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack)
        {
            TryAttack(1);
        }
    }
}