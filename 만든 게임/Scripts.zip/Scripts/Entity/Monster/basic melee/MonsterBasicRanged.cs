using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterBasicRanged : MonsterAttack
{
    [SerializeField] private float delayBeforeAttack;       // ���� ������ �ð�
    public GameObject attackIndicator;                      // ���� ���� ǥ�� ������
    public GameObject[] spawnPos;
    public string projectileName;
    
    [SerializeField] private List<GameObject> spawnCount;
    private GameObject attackOmdocatprInstance;
    private int Count = 0;


    private void Update()
    {
        MonsterStateLogic();
    }

    // ȸ�� ����
    // �ϴ� ���߿� ����
    public void EvasiveManeuver()
    {
        if (AttackCoroutine != null)
            return;

        _monsterBaseInfo.isAttack = true;
        _monsterMovement.navMeshAgent.isStopped = false;
        AttackCoroutine = StartCoroutine(evasiveManeuverCoroutin());
    }

    IEnumerator evasiveManeuverCoroutin()
    {
        // ����ü
        Vector3[] directions = { Vector3.right, Vector3.left, Vector3.back };

        foreach (var direction in directions)
        {
            Debug.Log("ȸ��");
            if (!CheckObstacle(direction))
            {
                // ���⿡ ���缭 �ִϸ��̼� ȣ��
                // �ڷ�ƾ���� �ؼ� �̵��ϰ� �ؾ��� �ȱ׷� ������
                // ��� �ڷ� �и��� ���� ���� �ʿ�
                Vector3 evadeDirection = (transform.position + direction * _evadeDirection).normalized;



                //_monsterMovement.navMeshAgent.SetDestination(evadeDirection);
                // yield return new WaitUntil(() =>
                //_monsterMovement.navMeshAgent.remainingDistance <= _monsterMovement.navMeshAgent.stoppingDistance);// &&
                ///!anim.GetCurrentAnimatorStateInfo(0).IsName("EvadeAnimation"));

                // �� �ڵ� ���� ���Ͱ� ���� �߽��Ұž� �ϰ� ����
                float distanceEvasive = 0f;

                transform.rotation = Quaternion.LookRotation(evadeDirection);
                _monsterBaseInfo.moveSpeed *= 2;
                while (distanceEvasive < _evadeDirection)
                {
                    float step = Time.deltaTime * _monsterBaseInfo.moveSpeed;
                    transform.position += step * evadeDirection;
                    distanceEvasive += step;
                    yield return null;
                }
                break;
            }
        }
        //yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f);

        transform.LookAt(_monsterMovement.target);
        // ���� ���� ��Ȱ��ȭ
        yield return null;
        _monsterBaseInfo.moveSpeed /= 2;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;

        // ���Ÿ� ���� ȣ��
        StartRangeChargeAttack();
    }
    // ȸ�ǽ� �̵��� �������� ����
    private bool CheckObstacle(Vector3 direction)
    {
        RaycastHit hit;

        if (Physics.Raycast(transform.position, direction, out hit, _evadeDirection))
        {
            return true;
        }

        return false;
    }

    public void StartRangeChargeAttack()
    {
        if (AttackCoroutine != null)
            return;

        _monsterBaseInfo.isAttack = true;
        Vector3 targetPos = _monsterMovement.target.transform.position;
        RangeChargeAttack(targetPos);
    }

    public void RangeChargeAttack(Vector3 targetPos)
    {

        AttackCoroutine = StartCoroutine(RangedChargeAttackCoroutine(targetPos));
    }

    IEnumerator RangedChargeAttackCoroutine(Vector3 targetPos)
    {
        // ���� ���� ǥ��
        //attackOmdocatprInstance = Instantiate(attackIndicator, targetPos, Quaternion.identity);
        GameObject attackIndicator = ObjectPool.Instance.GetPooledObject("Indicate");
        attackIndicator.transform.position = targetPos;
        attackIndicator.transform.rotation = Quaternion.identity;

        attackIndicator.SetActive(true);

        yield return new WaitForSeconds(delayBeforeAttack);

        PerformRangedChargeAttack(targetPos);

        attackIndicator.SetActive(false);

        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
        //Destroy(attackOmdocatprInstance);
    }

    private void PerformRangedChargeAttack(Vector3 targetPos)
    {
        
        // ���� ���� ����
        GameObject projectile = ObjectPool.Instance.GetPooledObject(projectileName);

        if (projectile == null)
            return;

        Debug.Log("�߻� �غ�");

        anim.SetTrigger("isAttack");

        // ����ü �߻� ��ġ ����
        Projectile projectileScript = projectile.GetComponent<Projectile>();

        if (projectileScript == null)
        {
            Debug.LogError("����ü ��ũ��Ʈ�� ����");
            return;
        }

        projectile.transform.position = spawnPos[0].transform.position;
        //projectile.transform.rotation = transform.rotation;

        projectileScript.SetTarget(targetPos);

        // ������ ����
        SetDamage(0, attackPattern[0].damage);

        // ����ü Ȱ��ȭ
        projectile.SetActive(true);

        spawnCount.Add(projectile);
        Count++;
    }

    void ReTargetingAttack()
    {
        anim.SetTrigger("isRetarget");

        foreach(GameObject obj in spawnCount)
        {
            if (obj != null)
            {
                obj.GetComponent<Projectile>().SetTarget(_monsterMovement.target.transform.position);
            }
        }

        Count = 0;
        //spawnCount.Clear();
    }

    public void NomarlShot()
    {
        GameObject nomarShot = ObjectPool.Instance.GetPooledObject("fish");

        Projectile projectileScript = nomarShot.GetComponent<Projectile>();

        if (projectileScript == null)
        {
            Debug.LogError("����ü ��ũ��Ʈ�� ����");
            return;
        }
        anim.SetTrigger("isNomarl");
        nomarShot.transform.position = spawnPos[0].transform.position;
        projectileScript.SetTarget(_monsterMovement.target.transform.position);

        SetDamage(1, attackPattern[1].damage);

        nomarShot.SetActive(true);
        nomarShot.GetComponent<BoxCollider>().enabled = true;
    }

    public void RingWaveAttack()
    {
        if (AttackCoroutine != null)
            return;

        AttackCoroutine = StartCoroutine(RingWaveAttackCoroutin());
    }

    IEnumerator RingWaveAttackCoroutin()
    {
        _monsterBaseInfo.isAttack = true;

        anim.SetFloat("AnimSpeed", 0.5f);
        anim.SetTrigger("isAttack");

        //yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f);

        SetDamage(0, attackPattern[0].damage);
        attackJudgmentPrefab.SetActive(true);
        attackJudgment[0].EnableWeaponCollider();

        var WaveEffect = attackJudgmentPrefab.GetComponent<Animator>();

        yield return new WaitUntil(() => WaveEffect.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f);
        anim.SetFloat("AnimSpeed", 1f);
        
        attackJudgmentPrefab.SetActive(false);
        attackJudgment[0].DisableWeaponCollider();
        attackJudgment[0].IsAttackCheck = false;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }

    void MonsterStateLogic()
    {
        // ���� ���̸�
        if (_monsterBaseInfo.isAttack)
            return;

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.standoff)
        {
            StartObservePlayer();
        }


        if ((_monsterMovement.attackRange / 2) > _monsterMovement.distanceToTarget
            && _monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack
            && _monsterMovement.target != null)
        {
            TryAttack(1);
        }

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack)
        {
            TryAttack(0);

            // �Ϲ� ��
            TryAttack(2);
        }

        if(Count >= 5)
        {
            ReTargetingAttack();
        }

    }
}
