using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteSowrdMonster : MonsterBasicMelee
{
    [SerializeField] private float maxRadius = 10f;      // ���� ������ �ִ� ������ �Ÿ�
    [SerializeField] private float expansionSpeed = 2f;  // ���� ������ �ӵ�
    [SerializeField] private float attackDuration = 2f;  // ������ ���ӵǴ� �ð�
    [SerializeField] private LayerMask targetLayer;      // ���� Ž���� ���̾�
    [SerializeField] private float attackEffectLifetime = 2f; // ����Ʈ ���� �ð�

    public GameObject attackEffect;


    private float currentRadius = 0f;
    private float animSpeed;
    private HashSet<Collider> hitTargetsSet = new HashSet<Collider>(); // �̹� ������ ���� �����ϴ� Set

    public void WideRangeAttack()
    {
        if (AttackCoroutine != null)
            return;

        _monsterBaseInfo.isAttack = true;
        AttackCoroutine = StartCoroutine(WideRangeAttackCorountin());
    }
    
    
    IEnumerator WideRangeAttackCorountin()
    {
        animSpeed = 0.5f;
        anim.SetFloat("AnimSpeed", animSpeed);
        anim.SetTrigger("WideRangeAttack");
        
        //WideRangeAttackEffect.transform.position = attackJudgment[1].transform.position;

        yield return new WaitForSecondsRealtime(1.5f);
        //WideRangeAttackEffect.SetActive(true);

        animSpeed = 1f;
        anim.SetFloat("AnimSpeed", animSpeed);

        SetDamage(1, attackPattern[3].damage);


        //attackJudgment[1].EnableWeaponCollider();

        yield return new WaitForSeconds(0.2f);
        //WideRangeAttackEffect.SetActive(false);

        //attackJudgment[1].DisableWeaponCollider();

        attackJudgment[1].IsAttackCheck = false;
        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }

    public void ExpandCircleAttack()
    {
        if (AttackCoroutine != null)
            return;

        _monsterBaseInfo.isAttack = true;
        AttackCoroutine = StartCoroutine(ExpandCircleAttackCoroutin());
    }

    IEnumerator ExpandCircleAttackCoroutin()
    {
        float startTime = Time.time;

        animSpeed = 0.2f;
        anim.SetFloat("AnimSpeed", animSpeed);
        anim.SetTrigger("ExpandCircleAttack");

        yield return new WaitForSecondsRealtime(0.75f);
        //// ���� ���� ����Ʈ Ȱ��ȭ
        attackEffect.transform.position = transform.position;
        attackEffect.transform.rotation = Quaternion.identity;
        attackEffect.SetActive(true);
        
        

        Vector3 sizeBack = attackEffect.transform.localScale;

        // �ʱ� ����Ʈ ũ�� ����
        Vector3 initialScale = attackEffect.transform.localScale;

        while (Time.time - startTime < attackDuration)
        {
            // ���� ������ Ȯ��
            currentRadius += expansionSpeed * Time.deltaTime;

            // ����Ʈ ũ�� ����
            attackEffect.transform.localScale = (initialScale * currentRadius) * 2;

            if (currentRadius > maxRadius)
                break;

            // ���� ���� ���� �� Ž��
            Collider[] hitTargets = Physics.OverlapSphere(transform.position, currentRadius, targetLayer);
            
            foreach (Collider target in hitTargets)
            {
                // �̹� �������� �� ������ Ȯ��
                if (!hitTargetsSet.Contains(target))
                {
                    Entity entity = target.GetComponent<Entity>();
                    if (entity != null)
                    {
                        Vector3 hitPoint = entity.transform.position;
                        Vector3 hitNormal = transform.position - entity.transform.position;
                        entity.TakeDamage(attackPattern[4].damage,hitPoint, hitNormal); // ������ �ֱ�
                        hitTargetsSet.Add(target); // �������� �� ���� Set�� �߰�
                    }
                    else
                    {
                        Debug.LogWarning("Entity ������Ʈ�� ����: " + target.name);
                    }
                    
                }
            }

            yield return null;
        }

        // ������ ������ Set �ʱ�ȭ
        hitTargetsSet.Clear();

        currentRadius = 0;

        animSpeed = 1f;

        attackEffect.SetActive(false);
        attackEffect.transform.localScale = sizeBack;

        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }

    
    

    public override void BattleStatusLogic()
    {
        // ���� ���̸�
        if (_monsterBaseInfo.isAttack)
            return;

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.standoff)
        {
            StartObservePlayer();
        }

        if (5 > _monsterMovement.distanceToTarget)
        {
            TryAttack(3);
        }
        if ((_monsterMovement.attackRange * 2) > _monsterMovement.distanceToTarget
            && _monsterBaseInfo.currentState != MonsterBaseInfo.MonsterState.attack
            && _monsterMovement.target != null)
        {
            TryAttack(0);
        }

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack)
        {
            TryAttack(4);
            TryAttack(1);
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, currentRadius); // ���� ���� ����׿�
    }
}
