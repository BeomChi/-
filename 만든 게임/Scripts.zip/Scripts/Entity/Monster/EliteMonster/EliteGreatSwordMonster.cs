using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteGreatSwordMonster : MonsterBasicMelee
{
    
    [SerializeField] private List<GameObject> projectileList = new List<GameObject>();  // ����ü ����
    public GameObject[] spawnPos;
    public void FakeGreatKaria()
    {
        if (AttackCoroutine != null)
            return;

        AttackCoroutine = StartCoroutine(FakeGreatKariaCoroutin());
    }

    IEnumerator FakeGreatKariaCoroutin()
    {
        _monsterBaseInfo.isAttack = true;
        _monsterMovement.navMeshAgent.isStopped = true;
        attackJudgment[0].IsAttackCheck = false;
        anim.SetTrigger("FakeGreatKaria");

        //transform.LookAt(_monsterMovement.target);
        SetDamage(0,attackPattern[2].damage);
        anim.SetFloat("AnimSpeed", 0.5f);

        //yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.25f);

        //attackJudgment[0].EnableWeaponCollider();

        //yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.5f);

        //attackJudgment[0].DisableWeaponCollider();

        yield return new WaitUntil(() => anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.95f);

        _monsterBaseInfo.isAttack = false;
        AttackCoroutine = null;
    }

    // ���� ��ȯ�� ���� ������ Ÿ������ ���������� �߻�
    public void FakeKariaMagic()
    {
        if (AttackCoroutine != null)
            return;

        AttackCoroutine = StartCoroutine(FakeKariaMagicCoroutin());
    }

    IEnumerator FakeKariaMagicCoroutin()
    {
        _monsterBaseInfo.isAttack = true;

        transform.LookAt(_monsterMovement.target);

        for (int i = 0; i < spawnPos.Length; i++)
        {
            GameObject obj = ObjectPool.Instance.GetPooledObject("SwordProjectile");
            Projectile projectile = obj.GetComponent<Projectile>();
            projectile.isStop = true;
            obj.transform.position = spawnPos[i].transform.position;
            //obj.transform.rotation = Quaternion.identity;
            obj.SetActive(true);

            projectileList.Add(obj);
        }
        _monsterBaseInfo.isAttack = false;

        float rand = Random.Range(0.5f, 2f);
        yield return new WaitForSeconds(rand);

        SetDamage(1, attackPattern[3].damage);

        foreach (GameObject obj in projectileList)
        {
            
            Projectile projectileScript = obj.GetComponent<Projectile>();
            Vector3 target = _monsterMovement.target.transform.position;
            target.y += 1;
            projectileScript.SetTarget(target);
            projectileScript.isStop = false;

            yield return new WaitForSeconds(0.3f);  // �� ����ü ���� ���� �ð� ����
        }

        projectileList.Clear();
        AttackCoroutine = null;
    }

    public override void BattleStatusLogic()
    {
        // ���� ���̸�
        if (_monsterBaseInfo.isAttack)
            return;

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.standoff)
        {
            StartObservePlayer();
        }


        if (_monsterMovement.distanceToTarget > 5
            && _monsterMovement.target != null)
        {
            TryAttack(3);
        }

        if ((_monsterMovement.attackRange * 2) > _monsterMovement.distanceToTarget
            && _monsterBaseInfo.currentState != MonsterBaseInfo.MonsterState.attack
            && _monsterMovement.target != null)
        {
            TryAttack(0);
        }

        if (_monsterBaseInfo.currentState == MonsterBaseInfo.MonsterState.attack)
        {
            TryAttack(2);
            TryAttack(1);
        }
    }
}
