//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public enum BuffType
//{
//    AttackIncrease = 0,
//    alleviationIncrease,
//    SpeedIncrease,
//}

//public enum DebuffType
//{
//    AttackDecrease = 0,
//    alleviationDecrease,
//    SpeedDecrease,
//}

//[System.Serializable]
//public class StatusEffect
//{
//    //public string effectName;           // ȿ�� �̸�
//    public BuffType? buffType;           // ���� Ÿ��
//    public DebuffType? debuffType;       // ����� Ÿ��
//    public float effectValue;           // ȿ�� ��
//    public float effectTime;            // ���ӽð�

//    // ? �� �ǹ�
//    // nullable Ÿ���� ��Ÿ����.
//    // �ش� ������ null ���� ���� ���� ����
//    public StatusEffect(BuffType? buff, DebuffType? debuff, float value, float duration)
//    {
//        //this.effectName = name;
//        this.buffType = buff;
//        this.debuffType = debuff;
//        this.effectValue = value;                       // ����� ������ ���� (0.1 = 10%)
//        this.effectTime = duration;
//    }

//    // ����/������� �����ϴ� �޼���
//    public void Apply(PlayerInfo playerInfo)
//    {
//        if (buffType == BuffType.AttackIncrease)
//        {
//            playerInfo.attackPower *= (1 + effectValue);
//        }
//        else if (debuffType == DebuffType.AttackDecrease)
//        {
//            playerInfo.attackPower *= (1 - effectValue);
//        }
//        else if (buffType == BuffType.alleviationIncrease)
//        {
//            playerInfo.decline_rate *= (1 + effectValue);
//        }
//        else if (debuffType == DebuffType.alleviationDecrease)
//        {
//            playerInfo.decline_rate *= (1 - effectValue);
//        }

       
//    }

//    // ����/������� �����ϴ� �޼���
//    public void Remove(PlayerInfo playerInfo)
//    {
//        if (buffType == BuffType.AttackIncrease)
//        {
//            playerInfo.attackPower /= (1 + effectValue);
//        }
//        else if (debuffType == DebuffType.AttackDecrease)
//        {
//            playerInfo.attackPower /= (1 - effectValue);
//        }
//        else if (buffType == BuffType.alleviationIncrease)
//        {
//            playerInfo.decline_rate /= (1 + effectValue);
//        }
//        else if (debuffType == DebuffType.alleviationDecrease)
//        {
//            playerInfo.decline_rate /= (1 - effectValue);
//        }

        
//    }
//}
