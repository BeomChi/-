using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivateMap : MonoBehaviour
{
    public GameObject[] whiteMap;
    public GameObject[] redMap;
    public GameObject[] redBossMap;
    public GameObject[] blueMap;
    public GameObject[] blueBossMap;
    public GameObject[] purpleMap;
    public GameObject[] yellowMap;
    public Material[] skyBox;

    public GameObject currentMap;
    public Material currentSkyBox;

    public bool check;
    
    PlayerManager playerManager;
    ObjectPool pool;
    private void Start()
    {
        playerManager =PlayerManager.Instance;
        pool = ObjectPool.Instance;
        Cursor.visible = false;
    }

    private void Awake()
    {
        Application.targetFrameRate = 60;
    }
    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.T))
        {
            int rand = Random.Range(0, 5);  // 0 ~ 4 ������ ����
            
            switch (rand)
            {
                case 0:
                    ChangeMap(whiteMap, skyBox[0]);
                    break;
                case 1:
                    ChangeMap(redMap, skyBox[1]);
                    break;
                case 2:
                    ChangeMap(blueMap, skyBox[2]);
                    break;
                case 3:
                    ChangeMap(purpleMap, skyBox[3]);
                    break;
                case 4:
                    ChangeMap(yellowMap, skyBox[0]);
                    break;
            }
        }
    }

    public void CallMapChang(string color)
    {
        switch (color)
        {
            case "White":
                ChangeMap(whiteMap, skyBox[0]);
                break;
            case "Red":
                ChangeMap(redMap, skyBox[1]);
                break;
            case "Blue":
                ChangeMap(blueMap, skyBox[2]);
                break;
            case "Purple":
                ChangeMap(purpleMap, skyBox[3]);
                break;
            case "Yellow":
                ChangeMap(yellowMap, skyBox[3]);
                break;
        }
    }

    public void CallBossMap(string color)
    {
        switch (color)
        {
            case "Red":
                CallBoss(redBossMap, skyBox[1]);
                break;
            case "Blue":
                CallBoss(blueBossMap, skyBox[2]);
                break;
        }
    }
    private void CallBoss(GameObject[] mapArray, Material skyboxMaterial)
    {
        // ��ī�̹ڽ� ���� ����
        if (currentSkyBox != null && currentSkyBox.name != skyboxMaterial.name
            && skyboxMaterial != null)
        {
            currentSkyBox = skyboxMaterial;
            ChangeSkybox(skyboxMaterial);
        }

        // �� ���� ����
        GameObject temp;

        if (currentMap.name == mapArray[0].name)
            Debug.LogError("����???");

        temp = mapArray[0];
        mapArray[0].SetActive(true);


        if (currentMap != null)
        {
            currentMap.SetActive(false);
        }

        MapSet();
        currentMap = temp;
    }
    private void ChangeMap(GameObject[] mapArray, Material skyboxMaterial)
    {
        // ��ī�̹ڽ� ���� ����
        if (currentSkyBox != null && currentSkyBox.name != skyboxMaterial.name
            && skyboxMaterial != null)
        {
            currentSkyBox = skyboxMaterial;
            ChangeSkybox(skyboxMaterial);
        }

        // �� ���� ����
        GameObject temp;
        while (true)
        {
            int rand = Random.Range(0, mapArray.Length);

            if (currentMap.name != mapArray[rand].name)
            {
                temp = mapArray[rand];
                mapArray[rand].SetActive(true);
                break;
            }
        }

        if (currentMap != null)
        {
            currentMap.SetActive(false);
        }

        MapSet();
        currentMap = temp;
    }

    public void ChangeSkybox(Material skyboxMaterial)
    {
        RenderSettings.skybox = skyboxMaterial;  // Skybox Material ����
        DynamicGI.UpdateEnvironment();  // ���� ���� ȯ�� ������Ʈ
    }

    void MapSet()
    {
        check = false;

        // ���� ������ �� Ŭ���� �̵� ȣ��
        StartCoroutine(MoveMapCheck());

        // ���� �������� ���� Ŀ�� �����
        Cursor.visible = check;
    }


    // �ʿ� �ִ� ���� �� ��Ҵ��� üũ�ϰ� ���̵� ��
    IEnumerator MoveMapCheck()
    {
        yield return new WaitForSeconds(3);

        int maxMonsterCount = playerManager.PlayerInfo.maxMonsterCount;

        if (maxMonsterCount != 0)
        {
            yield return new WaitUntil(() => playerManager.PlayerInfo.monsterCount == maxMonsterCount);

            check = true;

            pool.DeactivateAllObjectsInPools();

            // ���� ���� �� Ŀ�� ���̰� ��
            //Cursor.visible = check;
            playerManager.PlayerInfo.OpenMap();
        }
    }
}
