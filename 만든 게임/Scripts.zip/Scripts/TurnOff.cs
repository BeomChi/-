using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnOff : MonoBehaviour
{
    private void OnEnable()
    {
        StartCoroutine(FiveSeconds());
    }

    IEnumerator FiveSeconds()
    {
        yield return new WaitForSeconds(5);

        this.gameObject.SetActive(false);
    }
}
