using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Map_managers map_Managers;

    // Start is called before the first frame update
    void Start()
    {
        //StartCoroutine(Keyinput());
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //private IEnumerator Keyinput()
    //{
    //    //while (true)
    //    //{
    //    //    yield return null;
    //    //    if(Input.GetKeyDown(KeyCode.M))
    //    //    {
    //    //        map_Managers.MapCameraOn();
    //    //    }
    //    //}
    //}
}
