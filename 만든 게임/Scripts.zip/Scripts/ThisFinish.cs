using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThisFinish : MonoBehaviour
{
    private Ui_Manager ui_manager;

    private void Start()
    {
        //this.GetComponent<SphereCollider>().enabled = true;
    }

    private void OnEnable()
    {
        this.GetComponent<SphereCollider>().enabled = true;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            ui_manager = other.GetComponent<PlayerInfo>()._ui_Manager;            
            this.GetComponent<SphereCollider>().enabled = false;

            other.GetComponent<PlayerInfo>().gold += 100;
            ui_manager.GoldGuide();

            ui_manager.EventGuide("<color=yellow>M</color> Ű�� ���� ť�������");
            ui_manager.map_Managers.MapONoff_Corutine(true);
        }
    }    
}
