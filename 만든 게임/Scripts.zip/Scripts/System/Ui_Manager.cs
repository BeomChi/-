using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Ui_Manager : MonoBehaviour
{
    public Map_managers map_Managers;
    public PlayerManager player_manager;
    public SoundManager sound_manager;
    [Header("���� ����")]
    [SerializeField] private GameObject _NoticeBoard;
    [SerializeField] private TMP_Text _NoticeText;
    [SerializeField] protected Animator _NoticeAnimator;
    
    [Header("���� ����� ����")]
    public Transform BuffListTransform;
    public GameObject BuffPrefebs;
    public GameObject BuffGuide;
    public Sprite[] _buffImage;

    private List<Buff> BuffList;
    [SerializeField] private List<GameObject> BuffObj;
    //��������Ʈ {Ÿ��,��ȣ,�̸�,������,����}

    [Header("ü�°��� ������Ʈ")]
    public Transform _Hp_Postion;
    public GameObject _Hp_Obj;
    private List<GameObject> _Hp_Block_List = new List<GameObject>();

    [Header("�̺�Ʈ���ñ��� ǥ��")]
    public TMP_Text _eventGuide;

    [Header("���")]
    public TMP_Text _goldGuide;

    [Header("����ü�¹�")]
    public GameObject _bossHpBar;

    private void Start()
    {
        HpSetting();       
        
        StartCoroutine(CheatKey());//ġƮ
    }
    public IEnumerator NoticeBoard_shownHide(string name, Color color)
    {
        EventGuide("");

        _NoticeBoard.SetActive(true);
        _NoticeText.text = $"<{name}>";
        _NoticeText.color = color;
        _NoticeAnimator.Play("NoticeBoard_show");
        yield return new WaitForSeconds(3.5f);
        _NoticeBoard.SetActive(false);
    }
    #region ���� ����� ����Ʈ
    public void UpdateBuffList() //�̰� ȣ���� ����ߵǴµ�
    {
        BuffList = player_manager.PlayerInfo.activeEffect;

        //��� ���� �ϵ� ����
        foreach (GameObject obj in BuffObj)
        {
            obj.SetActive(false);
        }
        //������ ǥ��
        for (int i = 0; i < BuffList.Count; i++)
        {
            if (BuffObj.Count < BuffList.Count) // �����ִ밹�������� �߰�
            {
                BuffObj.Add(Instantiate(BuffPrefebs, BuffListTransform));
            }

            //Type
            if (BuffList[i].Type == 0)//�����
            {
                // ���������� X���� 0���� �����ϰ�, Y��� Z���� �״�� ����
                BuffObj[i].transform.GetChild(1).localEulerAngles = Vector3.zero;
                BuffObj[i].transform.GetChild(1).GetComponent<Image>().color = Color.red;
            }
            else 
            {
                // ���������� X���� 180���� �����ϰ�, Y��� Z���� �״�� ����
                BuffObj[i].transform.GetChild(1).localEulerAngles = new Vector3(0f, 0f, 180f);
                BuffObj[i].transform.GetChild(1).GetComponent<Image>().color = Color.green;
            }

            //����id�� ���� ���� ������ �ֱ�
            if (BuffList[i].Id == BuffeID.AttackIncrease || BuffList[i].Id == BuffeID.AttackDecrease)
                BuffObj[i].transform.GetChild(0).GetComponent<Image>().sprite = _buffImage[0];
            else if (BuffList[i].Id == BuffeID.alleviationIncrease || BuffList[i].Id == BuffeID.alleviationDecrease)
                BuffObj[i].transform.GetChild(0).GetComponent<Image>().sprite = _buffImage[1];
            else if (BuffList[i].Id == BuffeID.SpeedIncrease || BuffList[i].Id == BuffeID.SpeedDecrease)
                BuffObj[i].transform.GetChild(0).GetComponent<Image>().sprite = _buffImage[2];

            //���� ������ ǥ��
            BuffObj[i].transform.GetChild(2).GetComponent<TMP_Text>().text = BuffList[i].RemainingTurns.ToString();

            //���ٽ��̿��� ���߰� ���������� �����ذ��
            int indexBuffnum = i;

            // EventTrigger�� PointerEnter �̺�Ʈ �߰�
            EventTrigger trigger = BuffObj[indexBuffnum].GetComponent<EventTrigger>();

            //�ش� Ʈ���ſ� ���� �־ �װɷ� �������̵� ǥ�ÿ�

            // PointerEnter �̺�Ʈ
            EventTrigger.Entry pointerEnterEntry = new EventTrigger.Entry();
            pointerEnterEntry.eventID = EventTriggerType.PointerEnter;
            pointerEnterEntry.callback.AddListener((eventData) => { BuffGuideShow(indexBuffnum); });
            trigger.triggers.Add(pointerEnterEntry);            

            // PointerExit �̺�Ʈ
            EventTrigger.Entry pointerExitEntry = new EventTrigger.Entry();
            pointerExitEntry.eventID = EventTriggerType.PointerExit;
            pointerExitEntry.callback.AddListener((eventData) => { BuffGuideHide(); });
            trigger.triggers.Add(pointerExitEntry);
            

            //��ư Ȱ��ȭ
            BuffObj[i].SetActive(true);
        }
    }
    //���� ���̵� ǥ��
    private void BuffGuideShow(int num)
    {
        BuffGuide.SetActive(true);
        if (BuffList[num].Type == 0)
            BuffGuide.transform.GetChild(0).GetComponent<TMP_Text>().text = $"<color=red>{BuffList[num].Name}</color>";
        else
            BuffGuide.transform.GetChild(0).GetComponent<TMP_Text>().text = $"<color=green>{BuffList[num].Name}</color>";

        BuffGuide.transform.GetChild(0).GetComponent<TMP_Text>().text += $" \n���� ��: {BuffList[num].RemainingTurns}��\n" +
            $"{BuffList[num].Description}";          
    }
    private void BuffGuideHide()
    {
        BuffGuide.SetActive(false);
    }

    #endregion
    #region �÷��̾� ü�¹�
    private void HpSetting() //���� 1ȸ ȣ��
    {
        int currentHp = (int)player_manager.PlayerInfo.hp;
        int maxHp = (int)player_manager.PlayerInfo.maxHp;

        //ť�� �ϳ��� ü�� 20
        for (int i = 0; i < maxHp / 20; i++)
        {
            GameObject hpObj = Instantiate(_Hp_Obj, _Hp_Postion);
            hpObj.transform.localPosition = new Vector3(i * 100, 0, 0);
            _Hp_Block_List.Add(hpObj);
        }
        int remainingHp = maxHp % 20;
        if(remainingHp > 0) 
        {
            GameObject hpObj = Instantiate(_Hp_Obj, _Hp_Postion);
            int xPostion = ((maxHp / 20) + 1) * 100;
            hpObj.transform.localPosition = new Vector3(xPostion, 0, 0);
            float yRotation = 90 - (remainingHp * (90f / 20f));
            hpObj.transform.localEulerAngles = new Vector3(0, yRotation, 0);
            _Hp_Block_List.Add(hpObj);
        }
    }
    public void PlusMaxHpBlock(int num) //num ����Ƚ�� 1�� 20����
    {
        for (int i = 0; i < num; i++)
        {
            GameObject hpObj = Instantiate(_Hp_Obj, _Hp_Postion);
            int xPostion = (_Hp_Block_List.Count + i) * 100;
            hpObj.transform.localPosition = new Vector3(xPostion, 0, 0);                       
            _Hp_Block_List.Add(hpObj);
        }
        CurrentHpSetting();

    }
    public void CurrentHpSetting() //ü�� �����ø��� ȣ��
    {
        int currentHp = (int)player_manager.PlayerInfo.hp;

        int currentHpN20 = currentHp / 20;
        int remainingHp = currentHp % 20;

        if (remainingHp > 0)
        {
            GameObject hpObj = _Hp_Block_List[currentHpN20];
            float yRotation = 90 - (remainingHp * (90f / 20f));
            hpObj.transform.localEulerAngles = new Vector3(0, yRotation, 0);
        }
        if(currentHpN20 < _Hp_Block_List.Count)
        {
            int outherHpBox = _Hp_Block_List.Count - currentHpN20;
            if (remainingHp > 0)
                outherHpBox--;
            for (int i = 0; i < outherHpBox; i++)
            {
                _Hp_Block_List[^(i + 1)].transform.localEulerAngles = new Vector3(0, 90, 0);
            }
        }
        
        if(currentHp <= 0)
        {
            sound_manager.BgmSelect(sound_manager._gameover);
            sound_manager.GetComponent<AudioSource>().loop = false;
            _NoticeBoard.SetActive(true);            
            _NoticeText.text = "<���� ����>";
            _NoticeText.color = Color.red;
            _NoticeAnimator.Play("NoticeBoard_Hiding");   
            StartCoroutine(GameOver());
        }
    }
    private IEnumerator GameOver()
    {
        while (true)
        {
            yield return null;
            if(Input.anyKeyDown)
            {
                //��������
                SceneManager.LoadScene("MainScene");
            }
        }
    }
    #endregion
    //ȭ�� �߾ӿ� �ؽ�Ʈ ǥ�� 
    public void EventGuide(string chat)
    {
        _eventGuide.text = chat;
    }
    public void GoldGuide() //��� ȭ�鿡 ǥ��
    {
        _goldGuide.text = player_manager.PlayerInfo.gold.ToString() + " G";
        _goldGuide.GetComponent<AudioSource>().Play();
    }
    public void BossHpBarOn(string name,float maxHp) //���� ��ȯ�� ����
    {
        _bossHpBar.SetActive(true);
        _bossHpBar.transform.GetChild(3).GetComponent<TMP_Text>().text = name;
        _bossHpBar.GetComponent<Slider>().maxValue = maxHp;
        _bossHpBar.GetComponent<Slider>().value = maxHp;
    }
    public void BossHpAccese(float currenHp) //����ü�¿��� ���̸� ������Ʈ����
    {
        _bossHpBar.GetComponent<Slider>().value = currenHp;
        if(currenHp <= 0)
            _bossHpBar.SetActive(false);
    }


    public void GameClear(bool perfect)
    {
        _NoticeBoard.SetActive(true);
        _NoticeText.color = Color.yellow;
        if (perfect)
        {
            _NoticeText.text = "<�Ϻ� Ŭ����>";
        }
        else
        {
            _NoticeText.text = "<���� Ŭ����>";
        }

        sound_manager.BgmSelect(sound_manager._clear);
        sound_manager.GetComponent<AudioSource>().loop = false;

        _NoticeAnimator.Play("NoticeBoard_Hiding");
        StartCoroutine(GameOver());
    }

    // ġƮ
    private IEnumerator CheatKey()
    {
        while(true)
        {
            yield return null;
            yield return new WaitUntil(()=>Input.GetKeyDown(KeyCode.F1) || Input.GetKeyDown(KeyCode.F2) || Input.GetKeyDown(KeyCode.F3));
            if(Input.GetKeyDown(KeyCode.F1))
            {
                player_manager.PlayerInfo.hp = player_manager.PlayerInfo.maxHp;
                CurrentHpSetting();
            }
            else if(Input.GetKeyDown(KeyCode.F2))
            {
                player_manager.PlayerInfo.attackPower += 10;
                EventGuide($"���� ���ݷ�{player_manager.PlayerInfo.attackPower}");
                yield return new WaitForSeconds(1);
                EventGuide("");
            }
            else if(Input.GetKeyDown(KeyCode.F3))
            {
                player_manager.PlayerInfo.gold += 1000;
                GoldGuide();
            }
        }
    }
}
