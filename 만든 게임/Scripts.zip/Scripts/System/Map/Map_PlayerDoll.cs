using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map_PlayerDoll : MonoBehaviour
{
    private GameObject NextPlaceobj;
    private GameObject CurrentPlaceobj;

    private void OnTriggerEnter(Collider other)
    {
        if(other != null && other.tag == "MapPlace")
        {
            NextPlaceobj = other.gameObject;
            CurrentPlaceobj = this.transform.parent.gameObject;
        }
    }

    public GameObject NextPlace()
    {
        return NextPlaceobj;
    }
    public GameObject CurrentPlace()
    {
        return CurrentPlaceobj;
    }
}
