using Microsoft.Win32.SafeHandles;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class Map_Set : MonoBehaviour
{
    [SerializeField]
    private Transform _Core; //��������
    [Space]
    public GameObject _Cube;
    public GameObject _SelectBar;
    public GameObject _PlayerDoll;
    [Space]
    public Map_managers map_Managers;
    public Map_SelectBar map_SelectBar;
    [Space]
    public Material _M_Black;

    private int _axisIndex = 0; // ���� ������ �� �ε��� (0: x, 1: y, 2: z)

    private int _cubeRotationCount = 0;//�ʵ������ִ�Ƚ��

    private GameObject _PlayerNextPlace;
    private BoxCollider _PlayerBoxCollider;
    private Map_PlayerDoll map_PlayerDoll;

    private bool _isRotating = false;

    //�Է±��
    private List<ObjectState> _KeyInput_List = new List<ObjectState>();    

    #region �ѹ�� ����Ŭ���� {Ű�ڵ�,��ġ,ȸ��}
    public class ObjectState
    {
        public KeyCode keycode { get; private set; }
        public int axis { get; private set; }
        public Vector3 position { get; private set; }
        public Quaternion rotation { get; private set; }

        public ObjectState(KeyCode key,int axi, Vector3 pos, Quaternion rot)
        {
            keycode = key;
            axis = axi;
            position = pos;
            rotation = rot;
        }
        public KeyCode GetKeyCode() { return keycode; }
        public int GetAxis() { return axis; }
        public Vector3 GetPosition() { return position; }
        public Quaternion GetRotation() { return rotation; }

    }
    #endregion

    void Start()
    {
        _cubeRotationCount = 5;
        CubeSetting();
        SelectBarOnOff(true);
    }
    
    #region �⺻����
    private void CubeSetting()
    {
        SelectBarOnOff(false);
        map_Managers.MapRotationCount_UI(_cubeRotationCount); //������Ƚ�� ����ȭ
        for (int x = -1; x < 2; x++)
        {
            for (int y = -1; y < 2; y++)
            {
                for (int z = -1; z < 2; z++)
                {
                    if (x != 0 || y != 0 || z!= 0)
                    {
                        GameObject cube = Instantiate(_Cube, transform);
                        cube.transform.localPosition = new Vector3(x, y, z);
                        cube.gameObject.name = $"Cube({x},{y},{z})";

                        //���� �� ����
                        for (int i = 1; i < cube.transform.childCount; i++)
                        {
                            cube.transform.GetChild(i).gameObject.SetActive(false);
                        }

                        //�ٱ��� �� ť�길 �ѱ�
                        int[] xyz = { x, y, z };
                        for (int i = 0; i < 3; i++)
                        {
                            int childNumber = 0;
                            if (xyz[i] != 0)
                            {
                                childNumber = i * 2 + 1;
                                if (xyz[i] > 0)
                                    childNumber += 1;

                                cube.transform.GetChild(childNumber).gameObject.SetActive(true);
                            }
                        }

                        if(x == 0 && y == 0 && z == -1) //��������
                        {
                            //Transform startplace = cube.GetComponent<Map_PlaceColor>().GetChildObjectByName("White").transform;
                            Transform startplace = cube.transform.Find("White").transform;
                            _PlayerDoll = Instantiate(_PlayerDoll, startplace);
                            _PlayerBoxCollider = _PlayerDoll.GetComponent<BoxCollider>();
                            map_PlayerDoll = _PlayerDoll.GetComponent<Map_PlayerDoll>();
                        }
                    }
                    else
                    {
                        //�߽�
                    }
                }
            }
        }
        StartCoroutine(MapShake());
    }
    private IEnumerator MapShake()
    {
        //�� ����
        int ranNum = Random.Range(2, 8);
        for (int i = 0; i < ranNum; i++)
        {
            yield return null;
            KeyCode[] keyList = { KeyCode.W, KeyCode.S, KeyCode.A, KeyCode.D, };
            int keyNum = Random.Range(0, 2);
            yield return MapControlKeyCode(keyList[keyNum], false);
            keyNum = Random.Range(2, 4);
            yield return MapControlKeyCode(keyList[keyNum], false);
            yield return MapControlKeyCode(KeyCode.Space, false);
        }
    }
    #endregion

    #region ����Ʈ��
    public IEnumerator MapControl()
    {
        while (map_Managers._Map_Active)
        {
            KeyCode key = GetKeyCodeInput();
            if (key != KeyCode.None && _cubeRotationCount > 0)
            {
                yield return MapControlKeyCode(key, true);
            }
            yield return new WaitUntil(() => Input.anyKeyDown);
        }
    }
    private KeyCode GetKeyCodeInput()
    {
        foreach (KeyCode key in System.Enum.GetValues(typeof(KeyCode)))
        {
            if (Input.GetKeyDown(key))
                return key;
        }
        return KeyCode.None;
    }
    //Ư��Ű�� �־ ���� ȸ��������
    private IEnumerator MapControlKeyCode(KeyCode key,bool recording)
    {
        if (key == KeyCode.W)
        {
            ChageAxis(1);
        }
        else if (key == KeyCode.S)
        {
            ChageAxis(-1);
        }
        else if (key == KeyCode.Space)
        {
            TurnAxis();
        }
        else if (key == KeyCode.A)
        {
            if (recording)
            {
                RecordingKey(KeyCode.D);
            }
            yield return CoreRotat(false);
        }
        else if (key == KeyCode.D)
        {
            if (recording)
            {
                RecordingKey(KeyCode.A);
            }
            yield return CoreRotat(true);
        }
    }
    private void RecordingKey(KeyCode key)
    {
        ObjectState newobj = new ObjectState(key, _axisIndex, _SelectBar.transform.localPosition, _SelectBar.transform.rotation);
        _KeyInput_List.Add(newobj);
        _cubeRotationCount--;
        map_Managers.MapRotationCount_UI(_cubeRotationCount);
    }
    #endregion
    #region �÷��̾� ��Ʈ�� & ��ư
    public void PlayerTurn(){ StartCoroutine(PTrun()); }
    private IEnumerator PTrun() //���ư����߿� ĳ�������ȵǰ�
    {
        map_Managers.ButtonsOnOff(false);
        // ȸ���� ����(90��)�� �� ȸ�� �ð�(0.5��) ���� �ʴ�2���̵�
        float angle = 90f;
        float duration = 0.5f; // ȸ���� �Ϸ�Ǵ� �ð� (�ӵ��� 2��� �����ϱ� ���� ����)
        float rotationSpeed = angle / duration; // �ʴ� ȸ�� �ӵ� ���
        // ȸ�� �ð��� ��� �ð� �ʱ�ȭ
        float elapsedTime = 0f;
        // ���� ȸ�� ������ ��ǥ ȸ�� ���� ����
        float initialRotation = _PlayerDoll.transform.eulerAngles.x;

        // ȸ�� ����
        while (elapsedTime < duration)
        {
            // ��� �ð� ������Ʈ
            elapsedTime += Time.deltaTime;
            // ���� ȸ�� ���� ���
            float rotationAmount = rotationSpeed * Time.deltaTime;
            // ������Ʈ ȸ�� ����
            _PlayerDoll.transform.Rotate(Vector3.right * rotationAmount);
            yield return null;
        }

        int Rotx = Mathf.RoundToInt(_PlayerDoll.transform.eulerAngles.x / 90f) * 90;
        _PlayerDoll.transform.eulerAngles = new Vector3 (Rotx,_PlayerDoll.transform.eulerAngles.y,_PlayerDoll.transform.eulerAngles.z);
        map_Managers.ButtonsOnOff(true);
    }
    public void PlayerConfirmed() //���� �����ִ�. ��Ӻ��� �������� ����Ű�������� ��¥�� ���Ͽ� �ѹ��̵��̴� �ϴ�����
    {
        //if (_cubeRotationCount <= 0) { return; } //ī��Ʈ������ 0
        map_Managers.ButtonsOnOff(false);
        GameObject nextmap = map_PlayerDoll.NextPlace();
        GameObject currentmap = map_PlayerDoll.CurrentPlace();
        if (nextmap != null && currentmap != null)
        {
            if (nextmap.name != "Black")
            {
                Quaternion xRotation = _PlayerDoll.transform.localRotation;
                _PlayerDoll.transform.SetParent(nextmap.transform);
                _PlayerDoll.transform.localPosition = Vector3.zero;
                _PlayerDoll.transform.localRotation = new Quaternion(xRotation.x, 0, 0, xRotation.w);
                
                currentmap.transform.GetChild(0).GetComponent<Renderer>().material = _M_Black;
                currentmap.name = "Black";

                //�ʺ� �̺�Ʈ
                map_Managers.MapEvent(nextmap);
                
                //�ѹ�� ��� �ʱ�ȭ
                _KeyInput_List.Clear();
            }           
            else
                map_Managers.ButtonsOnOff(true);
        }
    }
    //�ǵ�����
    public void Rollback() 
    {
        if (_KeyInput_List.Count != 0)
            StartCoroutine(RollBackCorutin());            
    }
    private IEnumerator RollBackCorutin()
    {
        map_Managers.ButtonsOnOff(false);
        ObjectState lastobj = _KeyInput_List[^1];
        _KeyInput_List.RemoveAt(_KeyInput_List.Count - 1);
        _axisIndex = lastobj.GetAxis();
        _SelectBar.transform.localPosition = lastobj.GetPosition();
        _SelectBar.transform.rotation = lastobj.GetRotation();

        yield return FlashSelectBar();
        yield return MapControlKeyCode(lastobj.GetKeyCode(), false);

        _cubeRotationCount++;
        map_Managers.MapRotationCount_UI(_cubeRotationCount);

        map_Managers.ButtonsOnOff(true);
    }
    //Ƚ������
    public void BuyRotationCount()
    {
        //Ƚ��1ȸ�� 100G
        _cubeRotationCount++;
        map_Managers.MapRotationCount_UI(_cubeRotationCount);
    }
    #endregion

    #region �����̵�
    private void ChageAxis(int Num)
    {
        map_Managers.ButtonsOnOff(false);

        Vector3 pos = Vector3.zero;
        switch (_axisIndex)
        {
            case 0:
                pos.x = MoveValue(_SelectBar.transform.localPosition.x + Num);
                break;
            case 1:
                pos.y = MoveValue(_SelectBar.transform.localPosition.y + Num);
                break;
            case 2:
                pos.z = MoveValue(_SelectBar.transform.localPosition.z + Num);
                break;
        }
        _SelectBar.transform.localPosition = pos;
        StartCoroutine(FlashSelectBar());
        map_Managers.ButtonsOnOff(true);
    }
    private float MoveValue(float num)
    {
        if (num == 2)
            num = -1;
        else if (num == -2)
            num = 1;

        return num;
    }
    #endregion

    #region �ຯ��
    private void TurnAxis()
    {
        map_Managers.ButtonsOnOff(false);
        _axisIndex = (_axisIndex + 1) % 3; // x(0), y(1), z(2) ��ȯ
        _SelectBar.transform.localPosition = Vector3.zero;

        switch (_axisIndex)
        {
            case 0:
                _SelectBar.transform.rotation = Quaternion.Euler(0, 0, 0);
                break;
            case 1:
                _SelectBar.transform.rotation = Quaternion.Euler(0, 0, 90);
                break;
            case 2:
                _SelectBar.transform.rotation = Quaternion.Euler(0, -90, 0);
                break;
        }
        StartCoroutine(FlashSelectBar());
        map_Managers.ButtonsOnOff(true);
    }
    #endregion

    #region ��ȸ��
    
    private IEnumerator CoreRotat(bool left)
    {
        if (!_isRotating)
        {
            map_Managers.ButtonsOnOff(false);
            Vector3 axis = Vector3.zero;
            if (left)
            {
                switch (_axisIndex)
                {
                    case 0: axis = Vector3.left; break;
                    case 1: axis = Vector3.down; break;
                    case 2: axis = Vector3.back; break;
                }
            }
            else
            {
                switch (_axisIndex)
                {
                    case 0: axis = Vector3.right; break;
                    case 1: axis = Vector3.up; break;
                    case 2: axis = Vector3.forward; break;
                }
            }

            float totalRotation = 0f;
            float rotationSpeed = 90f*2; // �ʴ� 90 * 2 �� ȸ��

            while (totalRotation < 90f)
            {
                float deltaRotation = rotationSpeed * Time.deltaTime;
                _Core.transform.Rotate(axis, deltaRotation);
                totalRotation += deltaRotation;
                yield return null;
            }

            // ȸ���� 90�� �ʰ��� ��� ��Ȯ�� 90���� ����
            _Core.transform.Rotate(axis, 90f - totalRotation);

            //�ڽĵ� ����
            foreach(Transform child in _Core.transform)
            {
                //���� ����
                int Anglex = Mathf.RoundToInt(child.eulerAngles.x / 90) * 90;
                int Angley = Mathf.RoundToInt(child.eulerAngles.y / 90) * 90;
                int Anglez = Mathf.RoundToInt(child.eulerAngles.z / 90) * 90;

                child.eulerAngles = new Vector3(Anglex, Angley, Anglez);

                //��ġ ����
                int Posx = Mathf.RoundToInt(child.transform.position.x);
                int Posy = Mathf.RoundToInt(child.transform.position.y);
                int Posz = Mathf.RoundToInt(child.transform.position.z);

                child.transform.position = new Vector3(Posx, Posy, Posz);
            }

            yield return FlashSelectBar();

            _isRotating = false;
            map_Managers.ButtonsOnOff(true);
        }
    }

    #endregion

    #region �ڽ��¿���
    private IEnumerator FlashSelectBar()
    {
        _SelectBar.SetActive(false);
        yield return null;

        ClearCore();
        map_SelectBar.ClearList();

        yield return null;
        _SelectBar.SetActive(true);
    }
    public void SelectBarOnOff(bool On)
    {
        _SelectBar.SetActive(On);
    }
    #endregion //�ڽ��� �ѹ� ���ٰ� �Ѽ� Ʈ���ſ��� �ޱ�����

    #region ȸ����� ������Ʈ �ʱ�ȭ
    private void ClearCore()
    {
        for (int i = _Core.transform.childCount - 1; i >= 0; i--)
        {
            // _Core�� ���� ������Ʈ ��������
            Transform child = _Core.transform.GetChild(i);

            // _box ������Ʈ�� ������ �̵�
            child.SetParent(transform);
        }
        _Core.transform.rotation = Quaternion.Euler(Vector3.zero);
    }
    #endregion
}
