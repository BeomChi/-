using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressEkey : MonoBehaviour
{
    private Ui_Manager ui_manager;

    private void Start()
    {
        //this.GetComponent<SphereCollider>().enabled = true;
    }

    private void OnEnable()
    {
        this.GetComponent<SphereCollider>().enabled = true;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            ui_manager = other.GetComponent<PlayerInfo>()._ui_Manager;
            other.GetComponent<PlayerInfo>().hp = other.GetComponent<PlayerInfo>().maxHp;
            this.GetComponent<SphereCollider>().enabled = false;
            StartCoroutine(Healtext());
        }
    }
    private IEnumerator Healtext()
    {
        yield return null;
        ui_manager.EventGuide("<color=green>ȸ�� �Ǿ����ϴ�.");
        yield return new WaitForSeconds(1);
        ui_manager.EventGuide("<color=yellow>M</color> Ű�� ���� ť�������");
    }
}
