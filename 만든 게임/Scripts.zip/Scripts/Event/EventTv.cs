using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventTv : MonoBehaviour
{
    public GameObject _tvBoss;
    public Ui_Manager _uiManager;

    private bool _isInArea;

    private IEnumerator PressKey()
    {
        while (_isInArea)
        {
            yield return null;
            if(Input.GetKeyDown(KeyCode.E))
            {
                _tvBoss.SetActive(true);
                _uiManager.BossHpBarOn("TV", _tvBoss.GetComponent<MonsterBaseInfo>().maxHp);
                _uiManager.EventGuide("");
                this.gameObject.SetActive(false);
            }
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            _uiManager = other.GetComponent<PlayerInfo>()._ui_Manager;
            _isInArea = true;
            StartCoroutine(PressKey());
            _uiManager.EventGuide("<color=yellow>E</color> Ű�� ���� ��ȣ�ۿ�");
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            _isInArea = false;
            _uiManager.EventGuide("");
        }
    }
}
