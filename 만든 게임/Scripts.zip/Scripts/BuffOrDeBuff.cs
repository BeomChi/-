using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuffOrDeBuff : MonoBehaviour
{
    private Ui_Manager ui_manager;
    public bool _isBuff;
    private bool isIn;
    private PlayerInfo _playerInfo;

    private void Start()
    {
        //this.GetComponent<SphereCollider>().enabled = true;
    }

    private void OnEnable()
    {
        this.GetComponent<SphereCollider>().enabled = true;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            ui_manager = other.GetComponent<PlayerInfo>()._ui_Manager;
            _playerInfo = other.GetComponent<PlayerInfo>();
            isIn = true;
            if (_isBuff)
            {
                ui_manager.EventGuide("<color=yellow>E</color> Ű�� ���� <color=green>����</color> ȹ��");
                StartCoroutine(BuffCorotin());
            }
            else
            {
                ui_manager.EventGuide("<color=yellow>E</color> Ű�� ���� 50% Ȯ���� <color=green>����</color> �Ǵ� <color=red>�����</color> ȹ��");
                StartCoroutine(RanBuffCorotin());
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            isIn = false;
            ui_manager.EventGuide("");
        }

    }
    private IEnumerator BuffCorotin()
    {
        while (isIn)
        {
            yield return null;
            if(Input.GetKeyDown(KeyCode.E))
            {
                _playerInfo.AddAttackBuff();
                this.GetComponent<SphereCollider>().enabled = false;

                ui_manager.EventGuide("<color=yellow>M</color> Ű�� ���� ť�������");
                ui_manager.map_Managers.MapONoff_Corutine(true);
                isIn = false;
            }
        }
    }
    private IEnumerator RanBuffCorotin()
    {
        while (isIn)
        {
            yield return null;
            if (Input.GetKeyDown(KeyCode.E))
            {
                int ran=Random.Range(0, 2);

                if(ran == 0)
                    _playerInfo.AddAttackBuff();
                else
                    _playerInfo.ReducedAttackBuff();

                this.GetComponent<SphereCollider>().enabled = false;

                ui_manager.EventGuide("<color=yellow>M</color> Ű�� ���� ť�������");
                ui_manager.map_Managers.MapONoff_Corutine(true);
                isIn = false;
            }
        }
    }
}
